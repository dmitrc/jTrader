Main link:
http://jtrade.user.jacobs-university.de

Please, use following FTP details in case you'd like to check the file structure:
ftp://dcucleschi-4:g2NRV9DL@userweb.jacobs-university.de

And these details if you'd like to check MySQL database:
https://userweb.jacobs-university.de/phpMyAdmin/
user: jtrade
pass: WxjcXFRH